##### vectors.R ####################################################################################

##### Introducing vectors --------------------------------------------------------------------------

set.seed(1234)
e <- rnorm(100)

X1 <- 1:10


##### Vector properties ----------------------------------------------------------------------------

##### Vector construction --------------------------------------------------------------------------

##### seq ------------------------------------------------------------------------------------------

pies <- seq(from = 0, by = pi, length.out = 5)
pies

i <- 1:5
i

year <- 2000:2004
year

block <- make_block(year, type = 'vector')
block


##### rep ------------------------------------------------------------------------------------------

i <- rep(pi, 100)
head(i)


##### Concatenation --------------------------------------------------------------------------------

i <- c(1, 2, 3, 4, 5)

j <- c(6, 7, 8, 9, 10)

k <- c(i, j)

l <- c(1:5, 6:10)


##### Growth by assignment -------------------------------------------------------------------------

i <- 1:10

i[30] = pi
i


##### Vector access - by index ---------------------------------------------------------------------

set.seed(1234)

e <- rnorm(100)

e[1]

e[1:4]

e[c(1,3)]


##### Vector access - logical access ---------------------------------------------------------------

i <- 5:9

i[c(TRUE, FALSE, FALSE, FALSE, TRUE)]

i[i > 7]

b <- i > 7
b

i[b]


##### which ----------------------------------------------------------------------------------------

i <- 11:20

which(i > 12)

i[which(i > 12)]


##### sample ---------------------------------------------------------------------------------------

months <- c("January", "February", "March", "April", "May", "June", "July", "August", "September",
            "October", "November", "December")

set.seed(1234)
mixedMonths <- sample(months)
head(mixedMonths)

set.seed(1234)
lotsOfMonths <- sample(months, size = 100, replace = TRUE)
head(lotsOfMonths)


##### sample II ------------------------------------------------------------------------------------

set.seed(1234)
moreMonths <- months[sample(1:12, replace = TRUE, size = 100)]
head(moreMonths)

# Cleaner with sample.int

set.seed(1234)
evenMoreMonths <- months[sample.int(length(months), size=100, replace=TRUE)]
head(evenMoreMonths)


##### order ----------------------------------------------------------------------------------------

set.seed(1234)
x <- sample(1:10)
x

order(x)
x[order(x)]


##### Vector arithmetic ----------------------------------------------------------------------------

B0 <- 5

B1 <- 1.5

set.seed(1234)
e <- rnorm(100, mean = 0, sd = 1)
e

X1 <- rep(seq(1,10), 10)
X1

Y <- B0 + B1 * X1 + e


##### Recycling ------------------------------------------------------------------------------------

vector1 <- 1:10
vector2 <- 1:5
scalar <- 3

print(vector1 + scalar)
print(vector2 + scalar)
print(vector1 + vector2)


##### Set theory - part I --------------------------------------------------------------------------

x <- 1:10
y <- 5:15

x %in% y


##### Set theory - part II -------------------------------------------------------------------------

?union

x <- 1900:1910
y <- 1905:1915

intersect(x, y)

setdiff(x, y)

setequal(x, y)

is.element(1941, y)


##### Summarization --------------------------------------------------------------------------------

x <- 1:50

sum(x)

mean(x)

max(x)

length(x)

var(x)


##### Vectors --------------------------------------------------------------------------------------

##### Exercise - Vectors ---------------------------------------------------------------------------

# 1. Create a vector of length 10, with years starting from 1980.

# 2. Create a vector with values from 1972 to 2012 in increments of four (1972, 1976, 1980, etc.)

# Construct the following vectors (feel free to use the VectorQuestion.R script):

FirstName <- c("Richard", "James", "Ronald", "Ronald", "George", "William", "William", "George",
               "George", "Barack", "Barack")

LastName <- c("Nixon", "Carter", "Reagan", "Reagan", "Bush", "Clinton", "Clinton", "Bush",
              "Bush", "Obama", "Obama")

# 3. List the last names in alphabetical order

# 4. List the years in order by first name.

# 5. Create a vector of years when someone named “George” was elected.

# 6. How many Georges were elected before 1996?

# 7. Generate a random sample of 100 presidents.


##### Answers - Vectors ----------------------------------------------------------------------------

# 1. Create a vector of length 10, with years starting from 1980.

years <- seq(from = 1980, length.out = 10)

# 2. Create a vector with values from 1972 to 2012 in increments of four (1972, 1976, 1980, etc.)

ElectionYear <- seq(from = 1972, to = 2012, by = 4)

# Construct the following vectors (feel free to use the VectorQuestion.R script):

FirstName <- c("Richard", "James", "Ronald", "Ronald", "George", "William", "William", "George",
               "George", "Barack", "Barack")

LastName <- c("Nixon", "Carter", "Reagan", "Reagan", "Bush", "Clinton", "Clinton", "Bush",
              "Bush", "Obama", "Obama")

# 3. List the last names in alphabetical order

LastName[order(LastName)]

# 4. List the years in order by first name.

ElectionYear[order(FirstName)]

# 5. Create a vector of years when someone named “George” was elected.

ElectionYear[FirstName == "George"]

# 6. How many Georges were elected before 1996?

myLogical <- (FirstName == "George") & (ElectionYear < 1996)

length(which(myLogical))

sum(myLogical)

sum(FirstName[years < 1996] == "George")

# 7. Generate a random sample of 100 presidents.

sample(LastName, 100, replace = TRUE)


##### Lists ----------------------------------------------------------------------------------------

x <- list()
typeof(x)

x[[1]] <- c("Hello", "there", "this", "is", "a", "list")

x[[2]] <- c(pi, exp(1))

summary(x)

str(x)

make_block(x)


##### [[ vs. [ -------------------------------------------------------------------------------------

##### REcursive storage ----------------------------------------------------------------------------

y <- list()

y[[1]] <- "Lou Reed"
y[[2]] <- 45

x[[3]] <- y

make_block(x)


##### List metadata --------------------------------------------------------------------------------

y[[1]] <- c("Lou Reed", "Patti Smith")
y[[2]] <- c(45, 63)

names(y) <- c("Artist", "Age")

y$Artist

y$Age

myList <- list(firstVector = c(1:10),
               secondVector = c(89, 56, 84, 298, 56),
               thirdVector = c(7,3,5,6,2,4,2))

lapply(myList, mean)

lapply(myList, median)

lapply(myList, sum)


##### List questions -------------------------------------------------------------------------------

# 1. Create a list with two elements. Have the first element be a vector with 100 numbers. Have the
# second element be a vector with 100 dates. Give your list the names: “Claim” and “Accident Date”.

# 2. What is the average value of the first list element?


##### Answers --------------------------------------------------------------------------------------

# 1. Create a list with two elements. Have the first element be a vector with 100 numbers. Have the
# second element be a vector with 100 dates. Give your list the names: “Claim” and “Accident Date”.

myList <- list()

myList$Claims <- rlnorm(100, log(10000))

myList$AccidentDate <- sample(seq.Date(as.Date('2008-01-01'), as.Date('2017-12-31'), length.out = 1000), 100)

# 2. What is the average value of the first list element?

mean(myList$Claims)


##### END CODE #####################################################################################